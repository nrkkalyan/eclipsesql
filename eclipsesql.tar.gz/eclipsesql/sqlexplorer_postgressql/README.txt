This package is licensed under LGPL version 2.

Some queries were taken from/inspired by pgadmin3 queries.

Initial Author: Rocco Rutte <pdmef@gmx.net>
