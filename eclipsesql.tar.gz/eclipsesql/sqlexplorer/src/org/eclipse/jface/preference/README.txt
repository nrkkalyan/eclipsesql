The ComboFieldEditor is borrowed from Eclipse 3.3 so that we can compile & deploy to Eclipse 3.2 platforms
